REAL AdMob IDs included:
APP_ID=ca-app-pub-9777598734881176~7262761895
BANNER=ca-app-pub-9777598734881176/8774621284
INTERSTITIAL=ca-app-pub-9777598734881176/4135528960

Calculator HTML included from user upload.
Just push to GitHub and run workflow to get AAB.