
package com.advancecalc.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.*

class MainActivity : AppCompatActivity() {
    private var mInterstitialAd: InterstitialAd? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/index.html")

        val adView = AdView(this)
        adView.adUnitId = "ca-app-pub-9777598734881176/8774621284"
        adView.setAdSize(AdSize.BANNER)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)

        val adViewParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        val webParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0, 1f
        )
        layout.addView(webView, webParams)
        layout.addView(adView, adViewParams)
        setContentView(layout)

        val interstitialRequest = AdRequest.Builder().build()
        InterstitialAd.load(this, "ca-app-pub-9777598734881176/4135528960", interstitialRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    mInterstitialAd = ad
                    webView.postDelayed({
                        mInterstitialAd?.show(this@MainActivity)
                    }, 8000)
                }
            })
    }
}
