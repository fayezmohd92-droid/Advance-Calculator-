@echo off
gradle %*